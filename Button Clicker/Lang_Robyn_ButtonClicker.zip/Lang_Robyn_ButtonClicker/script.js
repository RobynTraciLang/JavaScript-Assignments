function changeText(element){
    element.innerText = "Logout";
}

function pageAlert(){
    alert("Ninja was liked");
}

function remove(element){
    element.remove();
}