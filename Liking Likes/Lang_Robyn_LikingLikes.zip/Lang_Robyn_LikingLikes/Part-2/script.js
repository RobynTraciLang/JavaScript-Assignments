function increaseLikes1(){
    let post1Likes = document.querySelector("#post-1");
    post1Likes.innerText = Number(post1Likes.innerText) + 1;
}

function increaseLikes2(){
    let post2Likes = document.querySelector("#post-2");
    post2Likes.innerText = Number(post2Likes.innerText) + 1;
}

function increaseLikes3(){
    let post3Likes = document.querySelector("#post-3");
    post3Likes.innerText = Number(post3Likes.innerText) + 1;
}