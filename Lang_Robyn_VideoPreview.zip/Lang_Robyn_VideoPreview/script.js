console.log("page loaded...");

function playVideo(element) {
    element.play();
}

function stopVideo(element) {
    element.pause();
}