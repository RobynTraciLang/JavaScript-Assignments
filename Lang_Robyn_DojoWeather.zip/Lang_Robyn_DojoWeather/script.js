function loadingWeatherReport() {
    alert("Loading weather report...");
}

function dismissCookies() {
    let cookiesBox = document.querySelector("#cookies-box");
    cookiesBox.style.display = "none";
}
